#!/bin/bash

cd $(dirname ${1})

php code.php
