package main

type target struct {
	DBurl      string
	DBuser     string
	DBpwd      string
	ExpiryTime string
}
