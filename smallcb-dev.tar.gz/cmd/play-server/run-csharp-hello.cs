using System;
using System.Threading.Tasks;

namespace CouchbaseLiveDotNetExample
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello World");
        }
    }
}
