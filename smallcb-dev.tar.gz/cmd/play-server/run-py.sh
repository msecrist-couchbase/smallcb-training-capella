#!/bin/bash

cd $(dirname ${1})

python3 code.py
